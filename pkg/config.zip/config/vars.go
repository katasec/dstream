package config

import "github.com/katasec/dstream/pkg/logging"

var log = logging.GetLogger()
